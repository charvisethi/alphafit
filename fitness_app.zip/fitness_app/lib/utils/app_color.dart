import 'package:flutter/material.dart';

class AppColor {
  static const Color backgroundgrey = const Color(0xff6e7f80);
  static const Color backgroundblack = const Color(0xff000000);
  static const Color accentColor = Color(0xFFFFB412);
  static const Color btnColor = Color(0xfff2af4b);
  static const Color btnColor2 = Color(0xffF7904E);
  static const Color iconyellow = Color(0xffF7BA00);
}
